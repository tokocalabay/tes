require('./settings');
const _L = require('./lib/logger');
_L.update({ botName: global.namaBot || 'Lyppe BOT', owner: global.namaowner || '—' });


const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    generateWAMessage,
    jidDecode, 
    proto, 
    delay,
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");

const cfonts = require('cfonts');
const pino = require('pino');
const path = require("path");
const FileType = require('file-type');
const readline = require("readline");
const fs = require('fs');
const crypto = require("crypto")
const colors = require('colors')
const chalk = require('chalk')
const PhoneNumber = require('awesome-phonenumber');

const {
    Boom 
} = require('@hapi/boom');

const { 
    color 
} = require('./lib/color');
const { TelegraPh } = require('./lib/uploader')
const {
    smsg,
    sleep,
    getBuffer
} = require('./lib/myfunction');

const { 
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid,
    addExif
} = require('./lib/exif')

const {
     loadModule
     } = require('./lib/function');

const { createWelcomeCard, createGoodbyeCard } = require('./lib/canvas/welcomeCard');

// ── Watcher Showroom (di-port dari index.js) ──
let watcherShowroom = null;
try {
    ({ watcherShowroom } = require('./lib/showroomWatcher'));
} catch (e) {
    console.warn('[ShowroomWatcher] lib/showroomWatcher.js tidak ditemukan:', e.message);
}
// ← Ganti dengan ID grup kamu, ini yang bakal dikirimin notif live Showroom
const showroomGroupChats = [
    '120363426918178824@g.us',
    '120363312283295424@g.us'
];
let isWatchingShowroom = false;
let showroomIntervalId = null;

const _DBidx = require('./lib/db');
function gsGet(gid) { return _DBidx.gsGet(gid); }
function gsKey(gid, key, val) { return _DBidx.gsKey(gid, key, val); }

let _AB = null;
try {
    _AB = require('./lib/system/antibanSession');
    global._AB = _AB;
    console.log('[AntiBan] ✅ Anti-ban session system v3.0 loaded');
} catch (e) {
    console.warn('[AntiBan] ⚠️ lib/antibanSession.js tidak ditemukan:', e.message);
}

let _RL = null, _HM = null, _BotCfg = null;
try { _RL         = require('./lib/system/rateLimiter');   global._RL = _RL; } catch(e) { console.warn('[RateLimiter] file tidak ditemukan:', e.message); }
try { _HM         = require('./lib/system/healthMonitor'); } catch(e) { console.warn('[HealthMonitor] file tidak ditemukan:', e.message); }
try { _BotCfg     = require('./lib/system/botConfig');     global._BotCfg = _BotCfg; } catch(e) { console.warn('[BotConfig] file tidak ditemukan:', e.message); } 
const usePairingCode = true;

const question = (text) => {
    return new Promise((resolve) => {
        const rl = readline.createInterface({
            input:    process.stdin,
            output:   process.stdout,
            terminal: process.stdout.isTTY === true,
        });
        rl.question(text, (answer) => {
            rl.close();
            resolve(String(answer || '').trim());
        });
        rl.on('error', () => { try { rl.close(); } catch {} resolve(''); });
    });
};

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
cfonts.say('Lyppe BOT', 
{
    font: 'block',
    align: 'left',
    colors: ['#ff00ff', 'white'],
    background: 'transparent',
    rawMode: false,
});
async function Starts() {
	const { state, saveCreds } = await useMultiFileAuthState("./session");
    const Cantarella = makeWASocket({
        printQRInTerminal: false,
        syncFullHistory: false,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true, 
        version: await (async () => {
            try {
                const _ctrl = new AbortController();
                const _tid  = setTimeout(() => _ctrl.abort(), 8000);
                const _res  = await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json', { signal: _ctrl.signal });
                clearTimeout(_tid);
                return (await _res.json()).version;
            } catch {
                const { version: _fbv } = await fetchLatestBaileysVersion().catch(() => ({ version: [2, 3000, 1023000000] }));
                return _fbv;
            }
        })(),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({
            level: 'silent'
        }),
        auth: state
    });

    if (_AB) {
        // Simpan JID bot untuk referensi warmup & monitoring
        // Inisialisasi dilakukan saat connection 'open' agar Cantarella.user sudah tersedia
        global._AB_SOCK = Cantarella;
    }

    if (usePairingCode && !Cantarella.authState.creds.registered) {

        const phoneNumber = await question(`


‹⧼ © ${namaBot} ⧽›\`
‹⧼ Version ${versi} ⧽›
 ❖ Script by Lyppe BOT ❖ 
  Enter Your Number Here : `
);

        const code = await Cantarella.requestPairingCode(phoneNumber.replace(/[^0-9]/g,''), 'PREMIUMM');
        if (_BotCfg) { _BotCfg.setMainNumber(phoneNumber.replace(/[^0-9]/g,'')); _BotCfg.recordPairRequest(); }
        console.log('\n  This Your Pairing Code : ' + code);
    }

    store.bind(Cantarella.ev);

    Cantarella.ev.on("messages.upsert", async (chatUpdate, msg) => {
        try {
            const mek = chatUpdate.messages[0]
            if (!mek.message) return
            const _rlSender = (mek.key.participant || mek.key.remoteJid || '').split('@')[0];
            const _rlIsOwner = (Array.isArray(global.owner) ? global.owner : [String(global.owner || '')]).map(n => n.replace(/[^0-9]/g,'')).includes(_rlSender);
            if (!_rlIsOwner && global._RL && mek.key && !mek.key.fromMe) {
                const _rlCmd = (() => { try { const _b = (mek.message?.conversation || mek.message?.extendedTextMessage?.text || '').trim(); if (_b && global.prefix) { const _pfx = Array.isArray(global.prefix) ? global.prefix : [String(global.prefix)]; const _p = _pfx.find(p => _b.startsWith(p)); if (_p) return _b.slice(_p.length).trim().split(/\s+/)[0].toLowerCase(); } } catch {} return ''; })();
                if (_rlCmd) {
                    const _rlRes = global._RL.checkRateLimit((mek.key.participant || mek.key.remoteJid || ''), _rlCmd, false);
                    if (_rlRes.blocked) return;
                }
            }
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
            if (mek.key && mek.key.remoteJid === 'status@broadcast') {
                if (!mek.key.fromMe) {
                    try { await Cantarella.autoReadSW(mek); } catch (e) { console.error('[AutoReadSW]', e.message); }
                    try { await Cantarella.autoReactSW(mek); } catch (e) { console.error('[AutoReactSW]', e.message); }
                }
                return
            }
            if (!Cantarella.public && !mek.key.fromMe && chatUpdate.type === 'notify') {
    const _ownerList = (Array.isArray(global.owner) ? global.owner : [String(global.owner || '')])
        .map(n => n.replace(/[^0-9]/g, ''));
    const _rawSender = (mek.key.participant || mek.key.remoteJid || '')
        .split('@')[0].split(':')[0];
    if (!_ownerList.includes(_rawSender)) return;
}
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
            if (mek.key.id.startsWith('CantarellaHaxor_')) return;
            const m = smsg(Cantarella, mek, store)
            require("./Cantarella")(Cantarella, m, chatUpdate, store)
        } catch (err) {
            console.log(err)
        }
    });

    Cantarella.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };


const _GM_IMGS = {
    promote:        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f389.png',
    demote:         'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f4c9.png',
    add:            'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f91d.png',
    kick:           'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f6aa.png',
    closegroup:     'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f512.png',
    opengroup:      'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f513.png',
    locksettings:   'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f510.png',
    unlocksettings: 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f5dd.png',
    setdesc:        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f4dd.png',
    setname:        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f3f7.png',
    lockadd:        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f6e1.png',
    unlockadd:      'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f465.png',
    joinapproval:   'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f4cb.png',
    joinopen:       'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f4c4.png',
    ban:            'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f6ab.png',
};

const _GM_SLEEP = (ms) => new Promise(r => setTimeout(r, ms));

const _gmGetName = async (sock, jid) => {
    try {
        const num  = jid.split('@')[0];
        const info = await sock.onWhatsApp(jid).catch(() => null);
        const name = info?.[0]?.pushname || info?.[0]?.name || num;
        return { name, num };
    } catch {
        const num = jid.split('@')[0];
        return { name: num, num };
    }
};

// fakeQuoted statis — persis seperti di Cantarella.js tapi tanpa ketergantungan m
const _GM_FAKE_QUOTED = {
    key: {
        fromMe:      false,
        participant: '0@s.whatsapp.net',
        remoteJid:   'status@broadcast'
    },
    message: {
        productMessage: {
            product: {
                productImage:      { mimetype: 'image/jpeg', jpegThumbnail: '' },
                title:             'Lyppe BOT MultiDevice',
                description:       null,
                currencyCode:      'IDR',
                priceAmount1000:   'Lyppe BOT HAXOR',
                retailerId:        'Powered Lyppe BOT',
                productImageCount: 1
            },
            businessOwnerJid: '6283168758640@s.whatsapp.net'
        }
    }
};

// Kirim notif grup dengan visual card (format identik reply() Cantarella.js)
const _gmCard = async (sock, gid, imgKey, cardTitle, cardBody, msgText, mentions = []) => {
    try {
        await _GM_SLEEP(1500);
        const imgUrl = _GM_IMGS[imgKey] || global.thumnail2 || '';

        let thumbBuf = null;
        try {
            const _axios = require('axios');
            const _res   = await _axios.get(imgUrl, {
                responseType: 'arraybuffer',
                timeout:      6000,
                headers:      { 'User-Agent': 'WhatsApp/2.24.6.77 A' }
            });
            thumbBuf = Buffer.from(_res.data);
        } catch (_fe) {
            // fallback: coba global.thumnail2 jika imgUrl gagal
            try {
                if (global.thumnail2 && global.thumnail2 !== imgUrl) {
                    const _axios2 = require('axios');
                    const _res2   = await _axios2.get(global.thumnail2, {
                        responseType: 'arraybuffer',
                        timeout:      5000
                    });
                    thumbBuf = Buffer.from(_res2.data);
                }
            } catch {}
        }

        await sock.sendMessage(gid, {
            text: msgText,
            mentions,
            contextInfo: {
                mentionedJid:    mentions,
                isForwarded:     true,
                forwardingScore: 999,
                externalAdReply: {
                    title:                 cardTitle,
                    body:                  cardBody,
                    mediaType:             1,
                    previewType:           0,
                    renderLargerThumbnail: false,
                    showAdAttribution:     false,
                    // thumbnail (Buffer) = selalu muncul, tidak bergantung fetch WA
                    ...(thumbBuf ? { thumbnail: thumbBuf } : { thumbnailUrl: imgUrl }),
                    sourceUrl: ''
                }
            }
        }, { quoted: _GM_FAKE_QUOTED });
    } catch (e) {
        console.error('[GMCard] Error:', e.message);
    }
};

Cantarella.ev.on('groups.update', async (json) => {
    try {
        const res = json[0];
        if (!res) return;
        const gid = res.id;
        const authorJid = res.author || res.actionAuthor || null;

        const _gsDB_path = './database/groupsettings.json';
        let _gsDB = {};
        try { _gsDB = JSON.parse(require('fs').readFileSync(_gsDB_path, 'utf8')); } catch {}
        const _gsCfg = _gsDB[gid] || {};
        if (_gsCfg.groupNotif === false) return;

        const adminInfo = authorJid ? await _gmGetName(Cantarella, authorJid) : { name: 'Admin', num: '0' };
        const adminMentions = authorJid ? [authorJid] : [];
        const adminTag = authorJid ? `@${adminInfo.num}` : adminInfo.name;

        if (res.announce === true) {
            await _gmCard(
                Cantarella, gid, 'closegroup',
                'GROUP CLOSED', 'Group Management',
                `*🔒 ᴄʟᴏꜱᴇ ɢʀᴏᴜᴘ*\n\n` +
                `╭┈┈⬡「 🔒 *sᴛᴀᴛᴜs ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Aksi: Grup Ditutup\n` +
                `┃ • Info: Hanya admin yg bisa kirim pesan\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Terkunci\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        } else if (res.announce === false) {
            await _gmCard(
                Cantarella, gid, 'opengroup',
                'GROUP OPENED', 'Group Management',
                `*🔓 ᴏᴘᴇɴ ɢʀᴏᴜᴘ*\n\n` +
                `╭┈┈⬡「 🔓 *sᴛᴀᴛᴜs ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Aksi: Grup Dibuka\n` +
                `┃ • Info: Semua member bisa kirim pesan\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Terbuka\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

        if (res.restrict === true) {
            await _gmCard(
                Cantarella, gid, 'locksettings',
                'SETTINGS LOCKED', 'Group Management',
                `*🔐 ʟᴏᴄᴋ sᴇᴛᴛɪɴɢꜱ*\n\n` +
                `╭┈┈⬡「 🔐 *ɪɴꜰᴏ ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Aksi: Pengaturan Dikunci\n` +
                `┃ • Info: Hanya admin yg bisa edit info grup\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Terkunci\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        } else if (res.restrict === false) {
            await _gmCard(
                Cantarella, gid, 'unlocksettings',
                'SETTINGS UNLOCKED', 'Group Management',
                `*🗝️ ᴜɴʟᴏᴄᴋ sᴇᴛᴛɪɴɢꜱ*\n\n` +
                `╭┈┈⬡「 🗝️ *ɪɴꜰᴏ ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Aksi: Pengaturan Dibuka\n` +
                `┃ • Info: Semua member bisa edit info grup\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Terbuka\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

        if (res.subject) {
            await _gmCard(
                Cantarella, gid, 'setname',
                'GROUP RENAMED', 'Group Management',
                `*🏷️ ꜱᴇᴛ ɴᴀᴍᴇ*\n\n` +
                `╭┈┈⬡「 🏷️ *ɴᴀᴍᴀ ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Nama Baru: ${res.subject}\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Berhasil Diubah\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

        if (res.desc !== undefined && res.desc !== null) {
            const descPreview = res.desc
                ? (res.desc.length > 80 ? res.desc.slice(0, 80) + '...' : res.desc)
                : '_(Dihapus)_';
            await _gmCard(
                Cantarella, gid, 'setdesc',
                'DESCRIPTION UPDATED', 'Group Management',
                `*📝 ꜱᴇᴛ ᴅᴇꜱᴄ*\n\n` +
                `╭┈┈⬡「 📝 *ᴅᴇꜱᴋʀɪᴘꜱɪ ɢʀᴏᴜᴘ* 」\n` +
                `┃ • Deskripsi Baru:\n` +
                `┃   _${descPreview}_\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Diperbarui\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

        if (res.memberAddMode === true) {
            await _gmCard(
                Cantarella, gid, 'lockadd',
                'ADD MEMBER LOCKED', 'Group Management',
                `*🛡️ ʟᴏᴄᴋ ᴀᴅᴅ ᴍᴇᴍʙᴇʀ*\n\n` +
                `╭┈┈⬡「 🛡️ *ᴀᴅᴅ ᴍᴇᴍʙᴇʀ* 」\n` +
                `┃ • Aksi: Add Member Dikunci\n` +
                `┃ • Info: Hanya admin yg bisa tambah member\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Restricted\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        } else if (res.memberAddMode === false) {
            await _gmCard(
                Cantarella, gid, 'unlockadd',
                'ADD MEMBER OPENED', 'Group Management',
                `*👥 ᴜɴʟᴏᴄᴋ ᴀᴅᴅ ᴍᴇᴍʙᴇʀ*\n\n` +
                `╭┈┈⬡「 👥 *ᴀᴅᴅ ᴍᴇᴍʙᴇʀ* 」\n` +
                `┃ • Aksi: Add Member Dibuka\n` +
                `┃ • Info: Semua member bisa undang teman\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Terbuka\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

        if (res.joinApprovalMode === true) {
            await _gmCard(
                Cantarella, gid, 'joinapproval',
                'JOIN APPROVAL ON', 'Group Management',
                `*📋 ᴊᴏɪɴ ᴀᴘᴘʀᴏᴠᴀʟ ᴏɴ*\n\n` +
                `╭┈┈⬡「 📋 *ᴊᴏɪɴ ᴀᴘᴘʀᴏᴠᴀʟ* 」\n` +
                `┃ • Aksi: Persetujuan Bergabung Aktif\n` +
                `┃ • Info: Member baru perlu persetujuan admin\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Enabled\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        } else if (res.joinApprovalMode === false) {
            await _gmCard(
                Cantarella, gid, 'joinopen',
                'JOIN APPROVAL OFF', 'Group Management',
                `*📄 ᴊᴏɪɴ ᴀᴘᴘʀᴏᴠᴀʟ ᴏꜰꜰ*\n\n` +
                `╭┈┈⬡「 📄 *ᴊᴏɪɴ ᴀᴘᴘʀᴏᴠᴀʟ* 」\n` +
                `┃ • Aksi: Persetujuan Bergabung Nonaktif\n` +
                `┃ • Info: Member bisa join bebas via link\n` +
                `┃ • Oleh: ${adminTag}\n` +
                `┃ • Status: ✅ Disabled\n` +
                `╰┈┈┈┈┈┈┈┈⬡`,
                adminMentions
            );
        }

    } catch (e) {
        console.error('[GroupsUpdate] Error:', e.message);
    }
});

// ── group-participants.update — promote / demote / add / kick (otomatis) ──────
Cantarella.ev.on('group-participants.update', async (_gmUpdate) => {
    try {
        const gid    = _gmUpdate.id;
        const action = _gmUpdate.action;
        const parts  = _gmUpdate.participants || [];
        const author = _gmUpdate.author || _gmUpdate.actionAuthor || null;

        if (!['promote', 'demote', 'add', 'remove'].includes(action)) return;

        const _gsDB_path = './database/groupsettings.json';
        let _gsDB = {};
        try { _gsDB = JSON.parse(require('fs').readFileSync(_gsDB_path, 'utf8')); } catch {}
        const _gsCfg = _gsDB[gid] || {};
        if (_gsCfg.groupNotif === false) return;

        const adminInfo = author ? await _gmGetName(Cantarella, author) : { name: 'Admin', num: '0' };
        const adminTag  = author ? `@${adminInfo.num}` : adminInfo.name;

        for (const userJid of parts) {
            const userInfo = await _gmGetName(Cantarella, userJid);
            const mentions = [userJid, ...(author ? [author] : [])];

            if (action === 'promote') {
                await _gmCard(
                    Cantarella, gid, 'promote',
                    'PROMOTED', 'Group Management',
                    `*🎉 ᴘʀᴏᴍᴏᴛᴇ*\n\n` +
                    `╭┈┈⬡「 🎉 *ᴘʀᴏᴍᴏᴛᴇ ᴀᴅᴍɪɴ* 」\n` +
                    `┃ • 👤 User: @${userInfo.num}\n` +
                    `┃ • 🏅 Role: Group Admin\n` +
                    `┃ • 👮 Oleh: ${adminTag}\n` +
                    `┃ • ✅ Status: Dipromote\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`,
                    mentions
                );
            } else if (action === 'demote') {
                await _gmCard(
                    Cantarella, gid, 'demote',
                    'DEMOTED', 'Group Management',
                    `*📉 ᴅᴇᴍᴏᴛᴇ*\n\n` +
                    `╭┈┈⬡「 📉 *ᴅᴇᴍᴏᴛᴇ ᴀᴅᴍɪɴ* 」\n` +
                    `┃ • 👤 User: @${userInfo.num}\n` +
                    `┃ • 📉 Role: Member Biasa\n` +
                    `┃ • 👮 Oleh: ${adminTag}\n` +
                    `┃ • 🔻 Status: Didemote\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`,
                    mentions
                );
            } else if (action === 'add') {
                await _gmCard(
                    Cantarella, gid, 'add',
                    'MEMBER JOINED', 'Group Management',
                    `*🤝 ᴍᴇᴍʙᴇʀ ʙᴀʀᴜ*\n\n` +
                    `╭┈┈⬡「 🤝 *ᴀᴅᴅ ᴍᴇᴍʙᴇʀ* 」\n` +
                    `┃ • 👤 User: @${userInfo.num}\n` +
                    `┃ • 🚪 Action: Bergabung ke Grup\n` +
                    `┃ • 👮 Oleh: ${adminTag}\n` +
                    `┃ • ✅ Status: Ditambahkan\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`,
                    mentions
                );
            } else if (action === 'remove') {
                await _gmCard(
                    Cantarella, gid, 'kick',
                    'MEMBER KICKED', 'Group Management',
                    `*🚪 ᴋɪᴄᴋ ᴍᴇᴍʙᴇʀ*\n\n` +
                    `╭┈┈⬡「 🚪 *ᴋɪᴄᴋ ᴍᴇᴍʙᴇʀ* 」\n` +
                    `┃ • 👤 User: @${userInfo.num}\n` +
                    `┃ • 🚫 Action: Dikeluarkan dari Grup\n` +
                    `┃ • 👮 Oleh: ${adminTag}\n` +
                    `┃ • ❌ Status: Kicked\n` +
                    `╰┈┈┈┈┈┈┈┈⬡`,
                    mentions
                );
            }

            await _GM_SLEEP(1200);
        }
    } catch (e) {
        console.error('[GMParticipants] Error:', e.message);
    }
});

Cantarella.ev.on('group-participants.update', async (anu) => {


if (!global._SCHEDULE_STARTED) {
    global._SCHEDULE_STARTED = true;
    setInterval(async () => {
        try {
            const _GS_PATH_SCH = "./database/groupsettings.json";
            let _schDB = {};
            try { _schDB = JSON.parse(require('fs').readFileSync(_GS_PATH_SCH,'utf8')); } catch(_e) {}

            const moment = require('moment-timezone');
            const _nowWIB  = moment().tz('Asia/Jakarta');
            const _nowTime = _nowWIB.format('HH:mm');
            const _nowSec  = _nowWIB.seconds();

            if (_nowSec > 10) return;

            for (const [gid, cfg] of Object.entries(_schDB)) {
                if (!cfg.scheduleActive || !cfg.scheduleOpen || !cfg.scheduleClose) continue;
                try {
                    const _groupInfo = await Cantarella.groupMetadata(gid).catch(() => null);
                    if (!_groupInfo) continue;
                    const _isAnnounce = _groupInfo.announce;

                    if (_nowTime === cfg.scheduleClose && !_isAnnounce) {

                        await Cantarella.groupSettingUpdate(gid, 'announcement');
                        await Cantarella.sendMessage(gid, {
                            text:
                                `🔒 *Grup Ditutup Otomatis!*\n\n` +
                                `⏰ Sesuai jadwal, grup ditutup pukul *${cfg.scheduleClose} WIB*.\n` +
                                `Hanya admin yang bisa mengirim pesan.\n\n` +
                                `🕐 Grup akan dibuka kembali pukul *${cfg.scheduleOpen} WIB*.\n` +
                                `_Selamat beristirahat! 🌙_`
                        });
                    } else if (_nowTime === cfg.scheduleOpen && _isAnnounce) {

                        await Cantarella.groupSettingUpdate(gid, 'not_announcement');
                        await Cantarella.sendMessage(gid, {
                            text:
                                `🔓 *Grup Dibuka Kembali!*\n\n` +
                                `☀️ Selamat pagi/siang/malam semua!\n` +
                                `Grup sudah dibuka pukul *${cfg.scheduleOpen} WIB*.\n` +
                                `Semua anggota bisa mengirim pesan kembali!\n\n` +
                                `🕙 Grup akan ditutup nanti pukul *${cfg.scheduleClose} WIB*.\n` +
                                `_Selamat beraktivitas! 🌟_`
                        });
                    }
                } catch(_e2) { console.error(`[Schedule] Error grup ${gid}:`, _e2.message); }
            }
        } catch(_e) { console.error('[Schedule checker]', _e.message); }
    }, 30 * 1000);
}
    console.log(anu)
    try {
        let metadata = await Cantarella.groupMetadata(anu.id).catch(()=>({}))
        let participants = anu.participants
        const _SLEEP = (ms) => new Promise(r => setTimeout(r, ms))

        const _GS_PATH = "./database/groupsettings.json";
        let _gsDB = {};
        try { _gsDB = JSON.parse(require('fs').readFileSync(_GS_PATH,'utf8')); } catch(_){}
        const _gsData = _gsDB[anu.id] || {};

        const GS_WELCOME_DEFAULT =
`    👋 SELAMAT DATANG!    

👤 *Member Baru:* @user
📂 *Grup:* @subject
👥 *Total Member:* @total anggota
📅 *Bergabung:* @date
📝 *Bio:* @bio

_Selamat datang! Semoga betah & patuhi aturan grup ya 🙏_`;

        const GS_LEAVE_DEFAULT =
`    👋 SELAMAT TINGGAL!    

👤 *Member:* @user
📂 *Grup:* @subject
👥 *Total Member:* @total anggota
📅 *Meninggalkan:* @date

_Semoga sukses selalu, sering main ke sini lagi ya! 🙏_`;

function _fmtMsg(template, data) {
    return (template || '')
        .replace(/@user/g,    `@${data.userId}`)
        .replace(/@subject/g, data.subject || 'Grup')
        .replace(/@desc/g,    data.desc    || '')
        .replace(/@date/g,    data.date    || new Date().toLocaleDateString('id-ID'))
        .replace(/@bio/g,     data.bio     || 'Tidak ada bio')
        .replace(/@total/g,   String(data.total || '?'));
}

for (let num of participants) {
    let ppuser;
    try {
        ppuser = await Cantarella.profilePictureUrl(num, 'image');
    } catch {
        ppuser = 'https://i.imgur.com/bGqSIIq.jpg';
    }

    let getBio = await Cantarella.fetchStatus(num).catch(() => ({ status: 'Tidak ada bio' }));

    const _msgData = {
        userId:  num.split('@')[0],
        subject: metadata.subject || 'Grup',
        desc:    metadata.desc    || '',
        date:    new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
        bio:     getBio?.status   || 'Tidak ada bio',
        total:   metadata.participants?.length || '?'
    };

    if (anu.action == 'add') {

        const _bannedList = _gsData.bannednumbers || [];
        if (_bannedList.includes(num)) {
            try {
                await Cantarella.groupParticipantsUpdate(anu.id, [num], 'remove');
                await Cantarella.sendMessage(anu.id, {
                    text: `🚫 *Auto-Kick: Nomor Terblokir!*\n\n@${num.split('@')[0]} ada dalam banned list grup ini dan otomatis dikeluarkan!`,
                    mentions: [num]
                });
            } catch (_e) {
                console.error('[BannedCheck]', _e.message);
            }
            continue;
        }

        if (_gsData.antiautobot) {
            let _isBot = false;
            try {
                const _uInfo = await Cantarella.onWhatsApp(num);
                const _pname = (_uInfo?.[0]?.name || '').toLowerCase();
                const _nClean = num.replace('@s.whatsapp.net', '');
                if (
                    /bot|robot|auto|system|service|assistant/i.test(_pname) ||
                    (_nClean.startsWith('1') && _nClean.length > 11) ||
                    _nClean.length < 7 ||
                    _nClean.length > 15
                ) _isBot = true;
            } catch (_e) {}
            if (_isBot) {
                try {
                    await Cantarella.groupParticipantsUpdate(anu.id, [num], 'remove');
                    await Cantarella.sendMessage(anu.id, {
                        text: `🤖 *Auto-Kick: Bot Terdeteksi!*\n\n@${num.split('@')[0]} terdeteksi sebagai bot otomatis dan dikeluarkan!`,
                        mentions: [num]
                    });
                } catch (_e) {}
                continue;
            }
        }

        if (!_gsData.welcome) {
            if (_gsData.verify && _gsData.verifyQuestion) {
                setTimeout(async () => {
                    try {
                        await _sendVerifyQuestion(Cantarella, anu.id, num, _gsData, metadata);
                    } catch (_ve) {
                        console.error('[Verify]', _ve.message);
                    }
                }, 5 * 60 * 1000);
            }
            continue;
        }

        const _wMsg = _fmtMsg(_gsData.welcomeMsg || GS_WELCOME_DEFAULT, _msgData);

        let _wCanvas = null;
        try {
            _wCanvas = await createWelcomeCard({
                username:    _msgData.userId,
                groupName:   _msgData.subject,
                memberCount: _msgData.total,
                avatar:      ppuser,
                background:  global.welcomeBg || null,
                blur:        global.welcomeBlur || 14,
                backgroundOverlay: global.welcomeOverlay || 0.48,
                botName:     global.namaBot || 'Lyppe BOT',
                message:     _msgData.bio
            });
        } catch (_wcErr) {
            console.error('[WelcomeCard]', _wcErr.message);
        }

        let sentMsg;
        try {
            sentMsg = await Cantarella.sendMessage(anu.id, {
                image:   _wCanvas ? _wCanvas : { url: ppuser },
                caption: _wMsg,
                mentions: [num]
            });
        } catch (_sendErr) {
            console.error('[WelcomeSend]', _sendErr.message);
            continue;
        }

        if (sentMsg && sentMsg.key) {
            setTimeout(async () => {
                try {
                    await Cantarella.sendMessage(anu.id, { delete: sentMsg.key });
                } catch (_) {}
            }, global.welcomeTimeout || 20000);
        }

        if (_gsData.verify && _gsData.verifyQuestion) {
            setTimeout(async () => {
                try {
                    await _sendVerifyQuestion(Cantarella, anu.id, num, _gsData, metadata);
                } catch (_ve) {
                    console.error('[Verify]', _ve.message);
                }
            }, 5 * 60 * 1000);
        }

    } else if (anu.action == 'remove') {

        if (!_gsData.leave) continue;

        const _lMsg = _fmtMsg(_gsData.leaveMsg || GS_LEAVE_DEFAULT, _msgData);

        let _lCanvas = null;
        try {
            _lCanvas = await createGoodbyeCard({
                username:    _msgData.userId,
                groupName:   _msgData.subject,
                memberCount: _msgData.total,
                avatar:      ppuser,
                background:  global.leaveBg || global.welcomeBg || null,
                blur:        global.leaveBlur || 14,
                backgroundOverlay: global.leaveOverlay || 0.50,
                botName:     global.namaBot || 'Lyppe BOT',
                message:     'Semoga sukses selalu!',
                reason:      _msgData.reason || ''
            });
        } catch (_lcErr) {
            console.error('[GoodbyeCard]', _lcErr.message);
        }

        let sentMsg;
        try {
            sentMsg = await Cantarella.sendMessage(anu.id, {
                image:   _lCanvas ? _lCanvas : { url: ppuser },
                caption: _lMsg,
                mentions: [num]
            });
        } catch (_sendErr) {
            console.error('[GoodbyeSend]', _sendErr.message);
            continue;
        }

        if (sentMsg && sentMsg.key) {
            setTimeout(async () => {
                try {
                    await Cantarella.sendMessage(anu.id, { delete: sentMsg.key });
                } catch (_) {}
            }, global.leaveTimeout || 20000);
        }
    }

    await _SLEEP(1500);
}
} catch (err) {
    console.log('[GroupParticipants] Error:', err);
}
});

Cantarella.ev.on('group-participants.update', async (_gpUpdate) => {
  try {
    const _gpChat = _gpUpdate.id;
    const _gpAction = _gpUpdate.action;
    const _gpParticipants = _gpUpdate.participants || [];

    if (_gpAction !== 'add') return;

    const _gpData = gsGet(_gpChat);
    if (!_gpData.verification) return;

    const _gpQuestions = _gpData.verificationQuestions || [];
    if (!_gpQuestions.length) return;

    const _gpTimeout = _gpData.verificationTimeout || 600000;
    const _gpPending = _gpData.verificationPending || {};
    const _gpMaxAttempts = _gpData.verificationMaxAttempts || 3;
    const _gpDifficulty = _gpData.verificationDifficulty || 'all';
    const _gpAction2 = _gpData.verificationAction || 'kick';
    const _gpAutoMath = _gpData.verificationAutoMath;
    const _gpMultiQ = _gpData.verificationMultiQ;
    const _gpWhitelist = _gpData.verificationWhitelist || [];
    const _gpBlacklist = _gpData.verificationBlacklist || [];
    const _gpCustomWelcome = _gpData.verificationWelcomeMsg || '';
    const _gpStats = _gpData.verificationStats || { total: 0, passed: 0, failed: 0, timeout: 0, kicked: 0 };
    const _gpLog = _gpData.verificationLog || [];

    let _gpGroupMeta;
    try { _gpGroupMeta = await Cantarella.groupMetadata(_gpChat); } catch { _gpGroupMeta = {}; }
    const _gpGroupName = _gpGroupMeta.subject || 'Grup';
    let _gpGroupLink;
    try { _gpGroupLink = await Cantarella.groupInviteCode(_gpChat); } catch { _gpGroupLink = null; }

    for (const _gpJid of _gpParticipants) {
      if (_gpBlacklist.includes(_gpJid)) {
        _gpLog.push({ jid: _gpJid, action: 'blacklist_kick', time: Date.now() });
        if (_gpLog.length > 500) _gpLog.splice(0, _gpLog.length - 500);
        gsKey(_gpChat, 'verificationLog', _gpLog);
        _gpStats.kicked = (_gpStats.kicked || 0) + 1;
        gsKey(_gpChat, 'verificationStats', _gpStats);
        await Cantarella.sendMessage(_gpChat, {
          text: `🚫 @${_gpJid.split('@')[0]} ada di blacklist dan akan dikeluarkan otomatis.`,
          mentions: [_gpJid]
        });
        try { await Cantarella.groupParticipantsUpdate(_gpChat, [_gpJid], 'remove'); } catch {}
        continue;
      }

      if (_gpWhitelist.includes(_gpJid)) {
        _gpLog.push({ jid: _gpJid, action: 'whitelist_skip', time: Date.now() });
        if (_gpLog.length > 500) _gpLog.splice(0, _gpLog.length - 500);
        gsKey(_gpChat, 'verificationLog', _gpLog);
        _gpStats.total = (_gpStats.total || 0) + 1;
        _gpStats.passed = (_gpStats.passed || 0) + 1;
        gsKey(_gpChat, 'verificationStats', _gpStats);
        await Cantarella.sendMessage(_gpChat, {
          text: `✅ @${_gpJid.split('@')[0]} ada di whitelist, verifikasi dilewati otomatis. Selamat datang!`,
          mentions: [_gpJid]
        });
        continue;
      }

      _gpStats.total = (_gpStats.total || 0) + 1;
      gsKey(_gpChat, 'verificationStats', _gpStats);

      const _gpVerifyId = (Math.random().toString(36).substring(2, 5) + Math.random().toString(36).substring(2, 5)).toUpperCase();

      let _gpSelectedQ;
      let _gpFiltered = _gpDifficulty === 'all' ? _gpQuestions : _gpQuestions.filter(q => q.difficulty === _gpDifficulty);
      if (!_gpFiltered.length) _gpFiltered = _gpQuestions;

      if (_gpAutoMath && Math.random() > 0.4) {
        const _ops = ['+', '-', 'x', '/'];
        const _op = _ops[Math.floor(Math.random() * _ops.length)];
        let _a, _b, _ans;
        if (_op === '+') { _a = Math.floor(Math.random() * 50) + 1; _b = Math.floor(Math.random() * 50) + 1; _ans = _a + _b; }
        else if (_op === '-') { _a = Math.floor(Math.random() * 50) + 10; _b = Math.floor(Math.random() * _a); _ans = _a - _b; }
        else if (_op === 'x') { _a = Math.floor(Math.random() * 15) + 2; _b = Math.floor(Math.random() * 12) + 2; _ans = _a * _b; }
        else { _b = Math.floor(Math.random() * 10) + 2; _ans = Math.floor(Math.random() * 15) + 2; _a = _b * _ans; }
        _gpSelectedQ = { q: `Berapa hasil dari ${_a} ${_op === 'x' ? '×' : _op} ${_b}?`, a: String(_ans), difficulty: 'auto-math' };
      } else {
        _gpSelectedQ = _gpFiltered[Math.floor(Math.random() * _gpFiltered.length)];
      }

      _gpPending[_gpJid] = {
        verifyId: _gpVerifyId,
        question: _gpSelectedQ.q,
        answer: _gpSelectedQ.a,
        expiry: Date.now() + _gpTimeout,
        attempts: 0,
        groupId: _gpChat,
        groupName: _gpGroupName,
        joinedAt: Date.now(),
        questionPhase: _gpMultiQ ? 1 : 0,
        difficulty: _gpSelectedQ.difficulty || 'unknown'
      };

      gsKey(_gpChat, 'verificationPending', _gpPending);

      _gpLog.push({ jid: _gpJid, action: 'verification_started', time: Date.now(), verifyId: _gpVerifyId });
      if (_gpLog.length > 500) _gpLog.splice(0, _gpLog.length - 500);
      gsKey(_gpChat, 'verificationLog', _gpLog);

      try {
        const _gpDmButtons = [];

        if (_gpGroupLink) {
          _gpDmButtons.push({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '📋 Masuk ke Grup',
              url: `https://chat.whatsapp.com/${_gpGroupLink}`
            })
          });
        }

        _gpDmButtons.push({
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: '❓ Cara Menjawab',
            id: `.jawab`
          })
        });

        if (global.nobot) {
          _gpDmButtons.push({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '📞 Hubungi Admin',
              url: `https://wa.me/${global.nobot}?text=Halo+kak+saya+butuh+bantuan+verifikasi+di+grup+${encodeURIComponent(_gpGroupName)}`
            })
          });
        }

        if (global.linkSaluran) {
          _gpDmButtons.push({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: '📢 Saluran',
              url: `https://whatsapp.com/channel/${global.linkSaluran?.split('/').pop() || ''}`
            })
          });
        }

        await Cantarella.sendMessage(_gpJid, {
          text:
            `👋 *Halo ${_gpJid.split('@')[0]}!*\n\n` +
            `Kamu baru saja bergabung di grup:\n` +
            `📋 *${_gpGroupName}*\n\n` +
            `🔒 Grup ini menggunakan sistem *verifikasi member*. Kamu perlu menyelesaikan verifikasi agar bisa berinteraksi penuh di grup.\n\n` +
            `${_gpCustomWelcome ? `> ${_gpCustomWelcome}\n\n` : ''}` +
            `╭┈┈⬡「 📌 *ʟᴀɴɢᴋᴀʜ ᴠᴇʀɪғɪᴋᴀsɪ* 」\n` +
            `┃ 1️⃣ Klik tombol di bawah untuk masuk ke grup\n` +
            `┃ 2️⃣ Lihat pertanyaan verifikasi di chat grup\n` +
            `┃ 3️⃣ Jawab dengan ketik di grup:\n` +
            `┃    .jawab <ID> <jawaban>\n` +
            `┃ 4️⃣ Jika benar → verifikasi selesai! ✅\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `╭┈┈⬡「 🆔 *ɪɴғᴏ ᴠᴇʀɪғɪᴋᴀsɪ ᴋᴀᴍᴜ* 」\n` +
            `┃ • ID: *${_gpVerifyId}*\n` +
            `┃ • Timeout: *${_gpTimeout / 60000} menit*\n` +
            `┃ • Max percobaan: *${_gpMaxAttempts} kali*\n` +
            `┃ • Mode: *${_gpMultiQ ? '2 Pertanyaan' : '1 Pertanyaan'}*\n` +
            `┃ • Gagal: *${_gpAction2}*\n` +
            `╰┈┈┈┈┈┈┈┈⬡\n\n` +
            `⏱️ *Batas waktu:* ${_gpTimeout / 60000} menit setelah pertanyaan muncul di grup\n\n` +
            `_Jika ada kendala, hubungi admin grup atau tekan tombol di bawah._`,
          footer: `${global.namaBot} • Verification System`,
          buttons: _gpDmButtons,
          headerType: 1
        });
      } catch {}

      await Cantarella.sendMessage(_gpChat, {
        text:
          `🔐 *ᴠᴇʀɪғɪᴋᴀsɪ ᴍᴇᴍʙᴇʀ ʙᴀʀᴜ*\n\n` +
          `> Halo @${_gpJid.split('@')[0]}! Selamat datang di *${_gpGroupName}* 👋\n\n` +
          `Untuk bisa berinteraksi di grup ini, kamu perlu menjawab pertanyaan berikut dengan benar.\n\n` +
          `╭┈┈⬡「 ❓ *ᴘᴇʀᴛᴀɴʏᴀᴀɴ${_gpMultiQ ? ' ᴋᴇ-1' : ''}* 」\n` +
          `┃\n` +
          `┃ ${_gpSelectedQ.q}\n` +
          `┃\n` +
          `╰┈┈┈┈┈┈┈┈⬡\n\n` +
          `🆔 *ID Verifikasi:* \`${_gpVerifyId}\`\n\n` +
          `╭┈┈⬡「 📝 *ᴄᴀʀᴀ ᴍᴇɴᴊᴀᴡᴀʙ* 」\n` +
          `┃ Ketik di chat grup:\n` +
          `┃ .jawab ${_gpVerifyId} <jawabanmu>\n` +
          `┃\n` +
          `┃ Contoh:\n` +
          `┃ .jawab ${_gpVerifyId} ${_gpSelectedQ.a}\n` +
          `╰┈┈┈┈┈┈┈┈⬡\n\n` +
          `╭┈┈⬡「 ⚙️ *ᴀᴛᴜʀᴀɴ* 」\n` +
          `┃ • Waktu: ${_gpTimeout / 60000} menit\n` +
          `┃ • Percobaan: ${_gpMaxAttempts} kali\n` +
          `┃ • Mode: ${_gpMultiQ ? '2 pertanyaan' : '1 pertanyaan'}\n` +
          `┃ • Gagal/timeout: ${_gpAction2}\n` +
          `╰┈┈┈┈┈┈┈┈⬡\n\n` +
          `_⚠️ Jawab sebelum waktu habis! Jika gagal ${_gpMaxAttempts}x atau timeout, kamu akan di-${_gpAction2}._`,
        footer: `${global.namaBot} • Verification System`,
        mentions: [_gpJid]
      });

      setTimeout(async () => {
        try {
          const _gpCurrentData = gsGet(_gpChat);
          const _gpCurrentPending = _gpCurrentData.verificationPending || {};

          if (_gpCurrentPending[_gpJid]) {
            delete _gpCurrentPending[_gpJid];
            gsKey(_gpChat, 'verificationPending', _gpCurrentPending);

            const _gpCurrentStats = _gpCurrentData.verificationStats || { total: 0, passed: 0, failed: 0, timeout: 0, kicked: 0 };
            _gpCurrentStats.timeout = (_gpCurrentStats.timeout || 0) + 1;
            if (_gpAction2 === 'kick') _gpCurrentStats.kicked = (_gpCurrentStats.kicked || 0) + 1;
            gsKey(_gpChat, 'verificationStats', _gpCurrentStats);

            const _gpCurrentLog = _gpCurrentData.verificationLog || [];
            _gpCurrentLog.push({ jid: _gpJid, action: 'timeout', time: Date.now(), verifyId: _gpVerifyId });
            if (_gpCurrentLog.length > 500) _gpCurrentLog.splice(0, _gpCurrentLog.length - 500);
            gsKey(_gpChat, 'verificationLog', _gpCurrentLog);

            await Cantarella.sendMessage(_gpChat, {
              text:
                `⏱️ *ᴠᴇʀɪғɪᴋᴀsɪ ᴛɪᴍᴇᴏᴜᴛ!*\n\n` +
                `> @${_gpJid.split('@')[0]} tidak menyelesaikan verifikasi\n` +
                `> dalam waktu ${_gpTimeout / 60000} menit.\n\n` +
                `╭┈┈⬡「 ⏱️ *ᴅᴇᴛᴀɪʟ* 」\n` +
                `┃ • Member: @${_gpJid.split('@')[0]}\n` +
                `┃ • ID: ${_gpVerifyId}\n` +
                `┃ • Action: ${_gpAction2}\n` +
                `╰┈┈┈┈┈┈┈┈⬡\n\n` +
                `${_gpAction2 === 'kick' ? '_Member dikeluarkan dari grup._' : ''}` +
                `${_gpAction2 === 'mute' ? '_Member di-mute._' : ''}` +
                `${_gpAction2 === 'warn' ? '_Member diberi peringatan._' : ''}`,
              mentions: [_gpJid]
            });

            if (_gpAction2 === 'kick') {
              try { await Cantarella.groupParticipantsUpdate(_gpChat, [_gpJid], 'remove'); } catch {}
            }

            try {
              await Cantarella.sendMessage(_gpJid, {
                text:
                  `⏱️ *ᴠᴇʀɪғɪᴋᴀsɪ ᴛɪᴍᴇᴏᴜᴛ*\n\n` +
                  `> Waktu verifikasi kamu di *${_gpGroupName}* telah habis.\n` +
                  `> Kamu tidak menjawab dalam ${_gpTimeout / 60000} menit.\n\n` +
                  `${_gpAction2 === 'kick' ? '> Kamu telah dikeluarkan dari grup.\n' : ''}` +
                  `_Hubungi admin jika ingin bergabung kembali._`
              });
            } catch {}
          }
        } catch {}
      }, _gpTimeout);
    }
  } catch {}
});

    Cantarella.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = Cantarella.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = {
                id,
                name: contact.notify
            };
        }
    });

    Cantarella.public = true;
    try {
        const _mf = JSON.parse(fs.readFileSync('./database/botmode.json','utf8'));
        if (typeof _mf.public === 'boolean') {
            Cantarella.public = _mf.public;
            console.log('[Mode] Loaded:', Cantarella.public ? 'PUBLIC' : 'SELF');
        }
    } catch {}

    Cantarella.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;


        try {
            const _CantarellaMod = require('./Cantarella');
            if (_CantarellaMod.updateConnectionState) _CantarellaMod.updateConnectionState(connection);
        } catch (_adConnErr) { /* silent */ }

        if (connection === 'open') {
            _L.exitPairingMode();
            _L.setBotInfo({
                botName: global.namaBot  || 'Lyppe BOT',
                owner:   global.namaowner || '—',
                mode:    Cantarella.public ? 'PUBLIC' : 'SELF',
                status:  'CONNECTED',
            });
            if (!global._LOGGER_TICKER) _L.startTicker();
            loadModule(Cantarella);
            try {
                const _ab = require('./lib/system/antibot');
                const _abOwnerJid = ((Array.isArray(global.owner)?global.owner[0]:global.owner)||'').replace(/[^0-9]/g,'') + '@s.whatsapp.net';
                _ab.init(async (msg) => { try { await Cantarella.sendMessage(_abOwnerJid, { text: msg }); } catch {} });
                global._ANTIBOT = _ab;
            } catch(e) { console.warn('[AntiBot] Init skip:', e.message); }
            if (_AB) {
                const _botJid = Cantarella.user?.id || '__bot__';
                global._BOT_JID = _botJid;
                if (!global._AB_INITIALIZED) {
                    _AB.initializeAll(Cantarella, _botJid);
                    global._AB_INITIALIZED = true;
                } else {
                    _AB.healthRecordConnect();
                    _AB.reconnectOnSuccess();
                }
                try { await Cantarella.sendPresenceUpdate('available'); } catch {}
            if (_HM) _HM.startHealthMonitor(Cantarella, {
                onGhost: (sock) => {
                    console.warn('[HealthMonitor] Ghost connection — forcing reconnect');
                    try { sock.end(new Error('ghost')); } catch {}
                }
            });
        }
 try {
    const _swgcMod = require('./Cantarella');
    if (_swgcMod.startAutoSwgcScheduler) {
        _swgcMod.startAutoSwgcScheduler(Cantarella);
    }
} catch(e) { console.error('[AutoSWGC] Gagal start:', e.message); }

try { await Cantarella.newsletterFollow("120363186130999681@newsletter"); } catch {}
try { await Cantarella.newsletterFollow("120363414017624228@newsletter"); } catch {}
        if (!global._SEWA_REMINDER_TIMER) {
            global._SEWA_REMINDER_TIMER = setInterval(async () => {
                // ...
            }, 60 * 60 * 1000);
        }

        // Watcher Showroom — interval terpisah biar ga saling nunggu fitur lain
        if (watcherShowroom) {
            if (showroomIntervalId) { clearInterval(showroomIntervalId); showroomIntervalId = null; }
            showroomIntervalId = setInterval(async () => {
                if (isWatchingShowroom) return;
                isWatchingShowroom = true;
                try {
                    await watcherShowroom(Cantarella, showroomGroupChats);
                } catch (e) {
                    console.log('Gagal kirim notifikasi Showroom:', e);
                } finally {
                    isWatchingShowroom = false;
                }
            }, 30000);
        }
    }

    if (connection === 'close') {
        _L.setStatus('RECONNECTING');
        if (showroomIntervalId) { clearInterval(showroomIntervalId); showroomIntervalId = null; }
        const code   = lastDisconnect?.error?.output?.statusCode
                    || lastDisconnect?.error?.statusCode
                    || DisconnectReason.connectionClosed;
        const reason = lastDisconnect?.error?.message || String(code);
        let guard = null;
        if (_AB) {
            _AB.healthRecordDisconnect(reason);
            guard = _AB.reconnectGuard(reason);
        }
        if (code !== DisconnectReason.loggedOut) {
            // Jangan reconnect instan: pakai delay/backoff dari antiban, dan cegah double-restart
            if (!global._RECONNECT_PENDING) {
                global._RECONNECT_PENDING = true;
                const delayMs = Math.max(3000, Math.round(guard?.delayMs || 3000));
                console.log(`[Reconnect] ${guard?.reason || 'reconnect'} — mulai lagi dalam ${Math.round(delayMs / 1000)}s`);
                setTimeout(() => {
                    global._RECONNECT_PENDING = false;
                    Starts().catch((e) => console.error('[Reconnect] Gagal:', e?.message || e));
                }, delayMs);
            }
        } else {
            console.log('\x1b[31m❌ Bot logout terdeteksi\x1b[0m');
            if (_HM) _HM.stopHealthMonitor();
        }
    }
});
     Cantarella.getName = (jid, withoutContact = false) => {
		id = Cantarella.decodeJid(jid)
		withoutContact = Cantarella.withoutContact || withoutContact
		let v
		if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
			v = store.contacts[id] || {}
			if (!(v.name || v.subject)) v = Cantarella.groupMetadata(id) || {}
			resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
		})
		else v = id === '0@s.whatsapp.net' ? {
			id,
			name: 'WhatsApp'
		} : id === Cantarella.decodeJid(Cantarella.user.id) ? Cantarella.user : (store.contacts[id] || {})
		return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
	}

    Cantarella.sendFile = async (jid, path, filename = '', caption = '', quoted = null, options = {}) => {
        try {

            let buffer;
            if (Buffer.isBuffer(path)) {
                buffer = path;
            } else if (typeof path === 'string') {
                if (/^data:.*?\/.*?;base64,/i.test(path)) {
                    buffer = Buffer.from(path.split`,`[1], 'base64');
                } else if (/^https?:\/\//.test(path)) {
                    buffer = await getBuffer(path);
                } else if (fs.existsSync(path)) {
                    buffer = fs.readFileSync(path);
                } else {
                    throw new Error('Invalid file path');
                }
            } else {
                throw new Error('Invalid input');
            }

            let fileType = await FileType.fromBuffer(buffer);
            let mime = fileType ? fileType.mime : 'application/octet-stream';
            let extension = fileType ? fileType.ext : 'bin';

            if (!filename) {
                if (typeof path === 'string' && !/^(data:|https?:\/\/)/.test(path)) {
                    filename = path.split('/').pop().split('\\').pop();
                } else {
                    filename = `file_${Date.now()}.${extension}`;
                }
            }

            let messageType;
            let messageContent = {};

            if (mime.startsWith('image/')) {
                messageType = 'imageMessage';
                messageContent = {
                    image: buffer,
                    caption: caption || '',
                    fileName: filename,
                    mimetype: mime,
                    ...options
                };
            } else if (mime.startsWith('video/')) {
                messageType = 'videoMessage';
                messageContent = {
                    video: buffer,
                    caption: caption || '',
                    fileName: filename,
                    mimetype: mime,
                    ...options
                };
            } else if (mime.startsWith('audio/')) {
                messageType = 'audioMessage';
                messageContent = {
                    audio: buffer,
                    mimetype: mime,
                    fileName: filename,
                    ...options
                };
            } else {
                messageType = 'documentMessage';
                messageContent = {
                    document: buffer,
                    fileName: filename,
                    mimetype: mime,
                    caption: caption || '',
                    ...options
                };
            }

            const media = await prepareWAMessageMedia(
                messageContent,
                {
                    upload: Cantarella.waUploadToServer,
                    mediaType: messageType.replace('Message', '').toLowerCase()
                }
            );

            return await Cantarella.sendMessage(jid, media, { quoted });

        } catch (err) {
            console.error('Error in sendFile:', err);
            throw err;
        }
    };

Cantarella.autoReadSW = async (m) => {
    if (!global.autoreadsw) return

    try {
        if (m.key && m.key.remoteJid === 'status@broadcast') {
            await Cantarella.readMessages([m.key])
            console.log('📱 Auto read status')
        }
    } catch (e) {

    }
}

Cantarella.autoReactSW = async (m) => {
    if (!global.autoreactsw) return

    try {
        if (m.key && m.key.remoteJid === 'status@broadcast') {
            const reaction = {
                react: {
                    text: global.autoreactemoji,
                    key: m.key
                }
            }
            await Cantarella.sendMessage(m.key.remoteJid, reaction)
            console.log(`😀 Auto reacted to status with ${global.autoreactemoji}`)
        }
    } catch (e) {
        console.error('Auto react error:', e)
    }
}

Cantarella.sendStatusMention = async (content, jids = []) => {
let users;
for (let id of jids) {
let userId = await Cantarella.groupMetadata(id)
users = await userId.participants.map(u => Cantarella.decodeJid(u.id))
}
let message = await Cantarella.sendMessage(
"status@broadcast", content, {
backgroundColor: "F54242",
font: Math.floor(Math.random() * 9),
statusJidList: users,
additionalNodes: [
{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {},
content: jids.map((jid) => ({ tag: "to", attrs: { jid }, content: undefined, })),
}, ], }, ], })
jids.forEach(id => {
Cantarella.relayMessage(id, {
groupStatusMentionMessage: {
message: {
protocolMessage: {
key: message.key,
type: 25,
}, }, }, },
{ userJid: Cantarella.user.jid, additionalNodes: [{
tag: "meta", attrs: { is_status_mention: "true" }, content: undefined, }, ], })
delay(2500)
})
return message
} 

    Cantarella.getFile = async (message, returnBuffer = true, savePath = '') => {
        try {
            if (!message || (!message.msg && !message.message)) {
                throw new Error('Invalid message');
            }

            const m = message.msg || message.message;
            let mime, messageType, filename;

            if (m.imageMessage) {
                mime = m.imageMessage.mimetype;
                messageType = 'image';
                filename = m.imageMessage.fileName || `image_${Date.now()}`;
            } else if (m.videoMessage) {
                mime = m.videoMessage.mimetype;
                messageType = 'video';
                filename = m.videoMessage.fileName || `video_${Date.now()}`;
            } else if (m.audioMessage) {
                mime = m.audioMessage.mimetype;
                messageType = 'audio';
                filename = m.audioMessage.fileName || `audio_${Date.now()}`;
            } else if (m.documentMessage) {
                mime = m.documentMessage.mimetype;
                messageType = 'document';
                filename = m.documentMessage.fileName || `document_${Date.now()}`;
            } else if (m.stickerMessage) {
                mime = m.stickerMessage.mimetype;
                messageType = 'sticker';
                filename = `sticker_${Date.now()}`;
            } else {
                throw new Error('Unsupported message type');
            }

            const stream = await downloadContentFromMessage(m, messageType);
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const fileType = await FileType.fromBuffer(buffer);
            let extension = 'bin';

            if (fileType) {
                extension = fileType.ext;
            } else if (mime) {
                extension = mime.split('/')[1]?.split(';')[0] || 'bin';
            }

            if (filename && !filename.includes('.')) {
                filename = `${filename}.${extension}`;
            }

            if (savePath) {
                const fullPath = savePath.endsWith('/') ? savePath + filename : savePath;
                fs.writeFileSync(fullPath, buffer);
                console.log(`File saved to: ${fullPath}`);
            }

            if (returnBuffer) {
                return {
                    buffer,
                    filename,
                    mime,
                    extension,
                    size: buffer.length
                };
            } else {
                return {
                    path: savePath ? (savePath.endsWith('/') ? savePath + filename : savePath) : null,
                    filename,
                    mime,
                    extension,
                    size: buffer.length
                };
            }

        } catch (err) {
            console.error('Error in getFile:', err);
            throw err;
        }
    };

     Cantarella.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo
}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo
}
} : {})
} : {})
await Cantarella.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage
}

Cantarella.sendTextWithMentions = async (jid, text, quoted, options = {}) => Cantarella.sendMessage(jid, {
        text: text,
        mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
        ...options
    }, {
        quoted
    })

    Cantarella.sendText = async (jid, text, quoted = '', options) => {
        Cantarella.sendMessage(jid, {
            text: text,
            ...options
        },{ quoted });
    }
    Cantarella.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])}
        return buffer
    }

    Cantarella.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? 
            path : /^data:.*?\/.*?;base64,/i.test(path) ?
            Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ?
            await (await getBuffer(path)) : fs.existsSync(path) ? 
            fs.readFileSync(path) : Buffer.alloc(0);

        let buffer;
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options);
        } else {
            buffer = await addExif(buff);
        }

        await Cantarella.sendMessage(jid, { 
            sticker: { url: buffer }, 
            ...options }, { quoted });
        return buffer;
    };

    Cantarella.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];

        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? filename + "." + type.ext : filename;
        await fs.writeFileSync(trueFileName, buffer);

        return trueFileName;
    };

    Cantarella.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? 
            path : /^data:.*?\/.*?;base64,/i.test(path) ?
            Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ?
            await (await getBuffer(path)) : fs.existsSync(path) ? 
            fs.readFileSync(path) : Buffer.alloc(0);

        let buffer;
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }

        await Cantarella.sendMessage(jid, {
            sticker: { url: buffer }, 
            ...options }, { quoted });
        return buffer;
    };

    Cantarella.albumMessage = async (jid, array, quoted) => {
        const album = generateWAMessageFromContent(jid, {
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32),
            },

            albumMessage: {
                expectedImageCount: array.filter((a) => a.hasOwnProperty("image")).length,
                expectedVideoCount: array.filter((a) => a.hasOwnProperty("video")).length,
            },
        }, {
            userJid: Cantarella.user.jid,
            quoted,
            upload: Cantarella.waUploadToServer
        });

        await Cantarella.relayMessage(jid, album.message, {
            messageId: album.key.id,
        });

        for (let content of array) {
            const img = await generateWAMessage(jid, content, {
                upload: Cantarella.waUploadToServer,
            });

            img.message.messageContextInfo = {
                messageSecret: crypto.randomBytes(32),
                messageAssociation: {
                    associationType: 1,
                    parentMessageKey: album.key,
                },    
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                forwardingScore: 99999,
                isForwarded: true,
                mentionedJid: [jid],
                starred: true,
                labels: ["Y", "Important"],
                isHighlighted: true,
                businessMessageForwardInfo: {
                    businessOwnerJid: jid,
                },
                dataSharingContext: {
                    showMmDisclosure: true,
                },
            };

            img.message.forwardedNewsletterMessageInfo = {
                newsletterJid: "0@newsletter",
                serverMessageId: 1,
                newsletterName: `WhatsApp`,
                contentType: 1,
                timestamp: new Date().toISOString(),
                senderName: "✧ Dittsans",
                content: "Text Message",
                priority: "high",
                status: "sent",
            };

            img.message.disappearingMode = {
                initiator: 3,
                trigger: 4,
                initiatorDeviceJid: jid,
                initiatedByExternalService: true,
                initiatedByUserDevice: true,
                initiatedBySystem: true,
                initiatedByServer: true,
                initiatedByAdmin: true,
                initiatedByUser: true,
                initiatedByApp: true,
                initiatedByBot: true,
                initiatedByMe: true,
            };

            await Cantarella.relayMessage(jid, img.message, {
                messageId: img.key.id,
                quoted: {
                    key: {
                        remoteJid: album.key.remoteJid,
                        id: album.key.id,
                        fromMe: true,
                        participant: Cantarella.user.jid,
                    },
                    message: album.message,
                },
            });
        }
        return album;
    };

    Cantarella.sendStatusMention = async (content, jids = []) => {
        let users;
        for (let id of jids) {
            let userId = await Cantarella.groupMetadata(id);
            users = await userId.participants.map(u => Cantarella.decodeJid(u.id));
        };

        let message = await Cantarella.sendMessage(
            "status@broadcast", content, {
                backgroundColor: "#000000",
                font: Math.floor(Math.random() * 9),
                statusJidList: users,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: jids.map((jid) => ({
                                    tag: "to",
                                    attrs: { jid },
                                    content: undefined,
                                })),
                            },
                        ],
                    },
                ],
            }
        );

        jids.forEach(id => {
            Cantarella.relayMessage(id, {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                userJid: Cantarella.user.jid,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    },
                ],
            });
            delay(2500);
        });
        return message;
    };

    Cantarella.ev.on('creds.update', saveCreds);
    return Cantarella;
}


if (!global._INDEX_PROC_GUARD) {
    global._INDEX_PROC_GUARD = true;
    process.on('uncaughtException', (err) => {
        _L.error('Process', `uncaughtException: ${err?.message || err}`);
        console.error('[CRITICAL]', err);
    });
    process.on('unhandledRejection', (reason, promise) => {
        _L.error('Process', `unhandledRejection: ${reason?.message || String(reason || '')}`);
    });
    process.on('SIGTERM', () => {
        _L.setStatus('OFFLINE');
        _L.log('Process', 'SIGTERM received — shutting down gracefully');
        process.exit(0);
    });
    process.on('SIGINT', () => {
        _L.setStatus('OFFLINE');
        _L.log('Process', 'SIGINT received — shutting down');
        process.exit(0);
    });
}
if (!global._STARTS_CALLED) {
    global._STARTS_CALLED = true;
    Starts().catch((e) => {
        console.error('[Starts] Fatal error:', e?.message || e);
        setTimeout(() => { global._STARTS_CALLED = false; Starts().catch(() => {}); }, 5000);
    });
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    global._STARTS_CALLED = false;
    require(file);
})